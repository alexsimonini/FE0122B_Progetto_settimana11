export const environment = {
  production: true,
  apiBaseUrl:"http://nomedominio.com/api"
};
